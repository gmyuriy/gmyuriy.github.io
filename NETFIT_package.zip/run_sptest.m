function run_sptest(SP,rndinit)
% WRAPPER TIME BIAS script
if(nargin<1) SP=0.1; end      %selection of SP
if(nargin<2) rndinit=3711; end%random initialization

fprintf('In run_sptest %g\n',SP);
% cd /hmt/sardine/hpc/scratch/stats/users/ym2289/glm-netfit

%%%%%%%%%%  SIMULATION NAME  -- unique to the project
netsim_name=sprintf('data/sptest-0924-%g',SP);

%INITIALIZE PARAMETERS
FR=66;              % imaging frame rate
N=50;               % network size
% SP=max(0.1,2/N);    % connections sparseness

spkM=1;             % spike-train samples from spk-sampler, for GLM
tmin=1;             % min coupling time-depth, >1
tmax=1;             % max coupling time-depth

Tp=tmax-tmin+1;     % couplings temporal depth

nrange{1}=1:N;      % neurons to process on this proc
id_proc=1;          % this processor
N_proc=1;           % num processors

flgSparse=1;        %compute sparse solution?
flgDale=0;          %compute dale solution?

mode='base';    %spike sampler base/iid/neal/indep-gibbs
spkM=1;         %adjust glm-sample size

NETFIT_main         %THIS ACTUALLY DOES THINGS
