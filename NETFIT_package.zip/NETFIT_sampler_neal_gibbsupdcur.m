%SCRIPT TO DRAW SAMPLE OF SPIKE HISTORIES FOR ESTIMATING W
% --- neal's MCMC + Gibbs
%UPDATE CURRENTS FOR NEURON K
for kk=1:N
  for t=tmin:tmax        
    offset=t-tmin+1;    
    nbuf0 = [zeros(1,t),H_loc{k}(1:end-t)];
    nbuf  = [zeros(1,t),H_new{k}(1:end-t)];
    J{kk} = J{kk}+Weights(kk,k,offset)*(nbuf-nbuf0);
  end
end

%clean the mess
clear nbuf nbuf0 kk 
