%PREPARE INITIAL DATA FOR METROPOLIS-HASTINGS IN WEAK APPROXIMATION SAMPLER 
%FOR HIDDEN NEURON WITH CALCIUM FLUORESCENT IMAGING OBSERVATIONS
%
% Y. Mishchenko 2009 Columbia Un
% K=1;                              %hidden neuron idx



%% COMPUTE DELAYED AND ADVANCED CURRENT
D1=0;
sampler_prep_hybrid

%some adjustements for P for backward recursion below
D1=length(netSim.cells(K).hrefr);
D2=length(netSim.cells(K).hrefr); %refraction state depth
P.h=netSim.cells(K).h(end-D1+1:end);
P.hr=netSim.cells(K).omega*netSim.cells(K).hrefr(end-D1+1:end);



%% COMPUTE BACKWARD RECURSION P(n|F_future)
dftMean=1E6;                      %enforcer max for fluor [prevet out of bounds for S(.)]
dftVar=1e10;                      %variance for nan/"impossible" fluor
lastT=netSim.T;                   %time bins in recursion
Ns=2^D2;                          %state space size /mixture components/
g=1-netSim.dt./netSim.cells(K).tau; %ca-decay factor



%% BACKWARD RECURSION POSTERIOR MEANS AND VARIANCE
r=netSim.K:netSim.K:netSim.T;
CM=repmat(nan,1,T);               %posterior mean
C2=repmat(nan,1,T);               %posterior variance

%CALCULATE S^-1(F)
P1.n    = netSim.n;
P1.k_d  = netSim.k_d;

%get normalized fluorescence value
S=(F(K,:)-netSim.cells(K).beta)/netSim.cells(K).alpha;
%enforce bounds
S(S<0)=0;
S(S>netSim.hill(P1,dftMean))=netSim.hill(P1,dftMean);

%mean and variance for Laplace
CM(r)=netSim.ihill(P1,S);
C2(r)=(netSim.dihill(P1,CM(r),S)/netSim.cells(K).alpha).^2.*...
          (netSim.cells(K).gamma*S+netSim.cells(K).zeta);
C2(isinf(C2))=nan;      
      
fprintf('mean P(C|F) variance - %g\n',mean(C2(~isnan(C2))));

%inialize p(n_T|F_T) - single gaussian at mean=M(T),var=S(T)
% p is the N x n matrix of weights p(q) for n components of the mixture
p=ones(Ns,1)/Ns;
m=repmat(0,Ns,1);
s2=repmat(dftVar,Ns,1);
%if have last gaussian, then enforce this
if(~isnan(C2(lastT)))
  m=repmat(CM(lastT),Ns,1); 
  s2=repmat(C2(lastT),Ns,1);
end

%BACKWARD RECURSION
r=[];                               %object representing mixture
r.P=p;                              % weights
r.M=m;                              % gauss. means
r.p=p;
r.m=m;
r.s2=s2;
r.z=0;

R=r;                                %array of mixtures through t
S=mod(0:Ns-1,2)';                   %spike at t in given state
for t=lastT-1:-1:1   
  %step 1: shift distr on ca & reform as a Gaussian(C)
  m=(m-(1-g)*netSim.cells(K).C_0-netSim.cells(K).A*repmat(S,[1 size(m,2)]))/g;
  s2=s2/g^2;
  p=p*g;
  
  %step 2: convolve with observations & reform as a Gaussians(C)
  Mean=CM(t);
  Sigma=C2(t);
  %if there is an observation ie
  if(~isnan(Sigma))
    mfg=(Mean*s2 + m*Sigma)./(s2+Sigma);
    s2fg=(Sigma*s2)./(s2+Sigma);
    Z=Mean^2/(2*Sigma)+m.^2./(2*s2)-mfg.^2./(2*s2fg);
    Z=1./sqrt(2*pi*(s2+Sigma)).*exp(-Z);
    p=p.*Z;
    m=mfg;
    s2=s2fg;
  end    
      
  %step 3: shift q as in [q*] -> [*q*], for each Gaussian component
  M=hmm_PXX(P,1:Ns,1:Ns,t);

  %step 4: re-group Gaussians
  pn=zeros(size(p)+[0 1]);
  mn=zeros(size(m)+[0 1]);
  s2n=zeros(size(s2)+[0 1]);  
  for qt=1:Ns
    state=dec2bin(qt-1,D1);             %state string for K    
    qpl=bin2dec([state(2:end),'1'])+1;
    qmn=bin2dec([state(2:end),'0'])+1;
    
    Mmn=M(qmn,qt);
    Mpl=M(qpl,qt);
    
    %n=1 gaussian
    pn(qt,1)=Mmn*p(qmn,1);
    mn(qt,1)=m(qmn,1);
    s2n(qt,1)=s2(qmn,1);
    
    %n=t+1 gaussian
    pn(qt,end)=Mpl*p(qpl,end);
    mn(qt,end)=m(qpl,end);
    s2n(qt,end)=s2(qpl,end);
    
    %n=2:t gaussians
    r=2:size(p,2);
    wpl=Mpl*p(qpl,r-1);
    wmn=Mmn*p(qmn,r);
    w=wpl+wmn;
    
    %special care to zero elements    
    pn(qt,r)=w;
    mn(qt,r(w==0))=m(qmn,r(w==0));
    s2n(qt,r(w==0))=s2(qmn,r(w==0));    
    
    r=r(w>0);     
    wpl=wpl(w>0);
    wmn=wmn(w>0);
    
    w=w(w>0);        
    mn(qt,r)=(wmn.*m(qmn,r)+wpl.*m(qpl,r-1))./w;
    mvar = (wmn.*(m(qmn,r)-mn(qt,r)).^2+wpl.*(m(qpl,r-1)-mn(qt,r)).^2)./w;
    s2n(qt,r)=(wmn.*s2(qmn,r)+wpl.*s2(qpl,r-1))./w + mvar;    
  end
    
  %update data structures
  z=sum(pn(:));               %normalize weights
  p=pn/z;
  m=mn;                       %new means
  s2=s2n;                     %new variances
  
  %create mixture object
  r=[];       
  %drop gaussians with zero total weights (ie below precision)
  ind=sum(p,1)>0;  
  r.P=sum(p,2);               %each state component weight
  r.M=sum(p.*m,2)./r.P;       %each state mean
  r.p=p(:,ind);               %all weights
  r.m=m(:,ind);               %all means
  r.s2=s2(:,ind);             %all variances
  r.z=R(end).z+log(z);        %total log-weight of mixture
  R(end+1)=r;                 %add mixture to array
  
  if(mod(t,round(netSim.T/25))==0) fprintf('.'); pause(0.01); end  
end
R=R(end:-1:1);
fprintf('\n');


%% DISPLAY GRAPH OF THE P(C|F_{future})
%comment below to disable FYI graph
fprintf('density graph of P(C|F_{future})...\n');
z=(1:1:150)';
dns2=zeros(length(z),length(R));
for t=1:length(R) 
    a=0;
    for i=1:size(R(t).m,1)
      A=repmat(z,1,size(R(t).m,2));
      A=A-repmat(R(t).m(i,:),size(z,1),1);
      A=-A.^2;
      A=A./repmat(R(t).s2(i,:),size(z,1),1)/2;
      A=A-repmat(max(A,[],1),size(z,1),1);
      A=exp(A);
      A=A./repmat(sum(A,1),size(z,1),1);
      A=A.*repmat(R(t).p(i,:),size(z,1),1);
      a=a+sum(A,2);
    end
    dns2(:,t)=a;
end
figure,imagesc(dns2),
title('[ca] prob density'),xlabel('ticks'),ylabel('[ca]');
hold on
r=netSim.K:netSim.K:netSim.T;
plot(r,CM(r),'yx','MarkerSize',12);