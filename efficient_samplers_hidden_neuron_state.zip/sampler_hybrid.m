%SAMPLE SEQUENCE OF STATES OF A HIDDEN NEURON FROM A POPULATION OF 
%COUPLED GLM NEURONS GIVEN STATES OF ALL OTHER NEURONS 
%
%HYBRID METROPOLIS-HASTINGS-HMM METHOD
%
% Y. Mishchenko 2009 Columbia Un
samples = 100;                    %samples to produce
burn = 100;                       %samples to burn



%% EXTRACT PARAMETERS
K=P.K;                            %hidden neuron
D1=P.D1;                          %state depth included in truncated HMM
T=netSim.T;                       %data length
Np=netSim.N;                      %total neurons

sD=length(netSim.cells(1).h);     %state depth
rD=length(netSim.cells(1).hrefr);
D=max(rD,sD);                     

lidx=((1:Np)==K);                 %hidden neuron selector
No=sum(~lidx);                    %total observed neurons
                                  
logrold=-Inf;                     %previous proposal's R=P/Q
trials=samples + burn;            %total trials

sample=false(trials,T);           %sample container

X=P.X;                            %results of the forward pass
Y=P.Y;
p=P.p;
pf=P.pf;

%% PREPARE PROPOSAL SAMPLES
tic
%get a proposal sample from HMM
[xr,qr]=hmm_sample(P,Y,X,p,pf,trials);
sr=mod(xr+1,2);                   %xr is 2^D1 states, convert=>{spike at t === xr even}


%% MH-LOOP
rcnt=0;                           %accepted move time-points
for cnt=1:trials
  %% Generate proposal                            :: CHECKED OUT
  n=false(1,T);                                 %spikes
  n=sr(cnt,:);                                  %proposal
  logq=qr(cnt);                                 %log(Q)
  
  %% Accept/reject proposal                       :: CHECKED OUT
  logp=0;                                       %log(P)
  Z=P.n;                                        %TOTAL proposed raster
  Z(K,:)=n;                              
  n=Z;
  H=false(Np,D);                                %container spike-history
  nbuf=false(Np,1);                             %buffer spike-history
  for t=1:T                                     %for all times    
    %injected currents:
    Ji=sum(H(:,end-sD+1:end).*[netSim.cells.h]',2); 
    %refractory currents
    Jj=sum(H(:,end-rD+1:end).*[netSim.cells.hrefr]',2); 
    
    f=f0(:,t);                                  %spontaneous
    g=-Jj.*[netSim.cells.omega]';               %refractory contribution    
    g=g+netSim.weights*Ji;                      %cross-current contribution
    
    nbuf=n(:,t);                                %new spikes that HAPPENED    
    H=[H(:,2:end),nbuf];                        %shift spike-history cont.
        
    pbuf=-exp(f+g)*P.dt;                        %update log(P)
    logp=logp+sum(log(1-exp(pbuf(nbuf))))+sum(pbuf(~nbuf));
  end
  
  logr=logp-logq;                               %log-ratio  P/Q
  
  r=logr-logrold;                               %MH-factor, log
  
  if(cnt==1 || rand<exp(r))                     %accept new move w/ R
    logrold=logr;
    sample(cnt,:)=n(K,:);
    if(cnt>burn) rcnt=rcnt+1; end    
  else
    sample(cnt,:)=sample(cnt-1,:);
  end
  
  if(mod(cnt,round(trials/25))==0) fprintf('.'); pause(0.01); end
end
sample=sample(burn+1:end,:);                    %burn samples
fprintf('R=%g\n',rcnt/samples);                 %print acceptance ratio
toc