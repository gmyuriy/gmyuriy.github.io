%% SAMPLERS DEMO, PHYSIOLOGICALLY REASONABLE NETWORK
K=1;                        %hidden neuron id

%simulate neural population
fprintf('Simulating neural population [physiol reasonable case]\n');
population_phys_sim

%WEAK SAMPLER
fprintf('Metropolis-Hastings sampler in weak approximation\n');
%prepare sampler data
sampler_prep_weak
%run sampler
sampler_weak

%HYBRID SAMPLER
fprintf('Hybrid Metropolis-Hastings-HMM sampler\n');
%prepare sampler data
D1=5;                       %depth of included truncated HMM
sampler_prep_hybrid
%run sampler
sampler_hybrid



%% SAMPLERS DEMO, STRONGLY COUPLED NETWORK
%simulate neural population
fprintf('\n\n\nSimulating neural population [strongly coupled case]\n');
population_strong_sim

%WEAK SAMPLER
fprintf('Metropolis-Hastings sampler in weak approximation\n');
%prepare sampler data
sampler_prep_weak
%run sampler
sampler_weak

%HYBRID SAMPLER
fprintf('Hybrid Metropolis-Hastings-HMM sampler\n');
%prepare sampler data
D1=5;                       %depth of included truncated HMM
sampler_prep_hybrid
%run sampler
sampler_hybrid



%% SAMPLERS DEMO, FLUORESCENCE OBSERVATIONS
%simulate neural population
fprintf('\n\n\nSimulating neural population with Fluor. Obs. [physiol reasonable case]\n');
population_phys_sim

%WEAK SAMPLER
fprintf('Metropolis-Hastings sampler with Fluorescent ca-imaging observations\n');
%prepare sampler data
sampler_prep_fluor
%run sampler
sampler_fluor