function [logp,jb,c]=glmlogp(n,netSim,jb,c,dr,tt)
%[logp,j,c]=glmlogp(n,netSim,j,c,dn,t)
%Calculate log P(n|model) for a proposal set of spike trains for neurons 
%n. Can be used to eithre compute log P from scratch or update previous
%calculation with a new spike at time t.
%
%[logp,j,c]=glmlogp(n,netSim);
%Calculated log P(n|model) from scratch for model netSim and spikes n.
%n is NxT array of spike trains for N neurons, netSim is a model object,
%see Manual. Returns
% logp    - spike trains log P
% j       - Nx(T+D) array of glm-currents
% c       - Nx(T+D) array of calcium variables
%D here is length of cross-current waveform h. j and c can be used to 
%quickly re-evaluate log P upon update of spike at position t;
%[logp,j,c]=glmlogp(n,netSim,j,c,dn,t)
%Updates log P(n|model) upon change of spiking state of K=1 neuron at t
%to new value dn.
%
% Y. Mishchenko  2010  Columbia Univ

%% PRELIM
K=1;                              %twicked neuron
T=size(n,2);                      %sequence length
Np=netSim.N;                      %all neurons
D=length(netSim.cells(1).h);      %state depth
Dr=length(netSim.cells(1).hrefr);

A     = [netSim.cells(K).A]';     %aliases
tau   = [netSim.cells(K).tau]';
C_0   = [netSim.cells(K).C_0]';
a     = netSim.dt./tau;
alpha   = netSim.cells(K).alpha;  %aliases
beta    = netSim.cells(K).beta;
gamma   = netSim.cells(K).gamma;
zeta    = netSim.cells(K).zeta;
P.n     = netSim.cells(K).n;
P.k_d   = netSim.cells(K).k_d;
D1=ceil(5*tau/netSim.dt);


if(nargin<3)                      %FULL CALCULATION
  logp=0;                                 %sum log(P)  
  c=zeros(1,T+D1);
  jb=zeros(Np,T+D);                       %currents
  H=false(Np,D);                          %spike history buffer
  f0=[netSim.cells.b0]';                  %time-varying baseline
  for t=1:T                               %for all times
    Ji=sum(H.*[netSim.cells.h]',2);       %cross-currents (E/IPSP)
    Jj=sum(H(:,end-Dr+1:end).*[netSim.cells.hrefr]',2);   %refractory currents
    
    g=f0(:,t);                            %spontaneous contribution
    g=g-Jj.*[netSim.cells.omega]';        %minus refractory contribution
    g=g+netSim.weights*Ji;                %plus cross-currents contribution
    
    nbuf=n(:,t);                          %new spikes here that HAPPENED
    H=[H(:,2:end),nbuf];                  %shift spike-history container
                                          %always contains last D spikes
    pbuf=-exp(g)*netSim.dt;               %update log(P)
    if(t==1) pbuf(:)=0; end               %no spike at t==1
    
    logp=logp+sum(log(1-exp(pbuf(nbuf))))+sum(pbuf(~nbuf));
    
    jb(:,t)=g;                            %update currents
    
    if(t==1)                              %correction for fluor obs
      c(t)=C_0;                    
    else 
      c(t)=max(0,(1-a).*c(t-1) + a.*C_0 + A.*nbuf(K));
    end    
  end
  
  rr=netSim.K:netSim.K:T;
  S=netSim.hill(P,c(rr));
  f=max(0,alpha*S+beta);                  %mean F
  s2=gamma*S+zeta;                        %var F
  logp=logp-sum((f-netSim.f(rr/netSim.K)).^2./s2+log(s2))/2;
else                              %SHORT CALCULATION
    lids=(1:Np)~=K;                       %add/subtract cur waveform
    h=netSim.cells(K).hrefr(end:-1:1)';
    H=[netSim.cells(lids).h]';
    H=H(:,end:-1:1);
    if(dr>0)                              %was 0 became 1
      jb(K,tt+1:tt+D)=jb(K,tt+1:tt+D)-h*netSim.cells(K).omega;
      jb(lids,tt+1:tt+D)=jb(lids,tt+1:tt+D)+H.*repmat(netSim.weights(lids,K),[1 D]);
    elseif(dr<0)                          %was 1 became 0
      jb(K,tt+1:tt+D)=jb(K,tt+1:tt+D)+h*netSim.cells(K).omega;
      jb(lids,tt+1:tt+D)=jb(lids,tt+1:tt+D)-H.*repmat(netSim.weights(lids,K),[1 D]);
    end

    rr=tt:min(tt+D,T);
    nbuf=n(:,rr);                    %update log(P)    
    pbuf=-exp(jb(:,rr))*netSim.dt;   
    logp=sum(log(1-exp(pbuf(nbuf))))+sum(pbuf(~nbuf));    

    
    if(dr>0)
      c(tt:tt+D1)=c(tt:tt+D1)+A*(1-a).^(0:D1);
    elseif(dr<0)
      c(tt:tt+D1)=c(tt:tt+D1)-A*(1-a).^(0:D1);
    end
    
    rr=tt:min(tt+D1,T);
    rr=rr(mod(rr,netSim.K)==0);    
    S=netSim.hill(P,c(rr));
    F=max(0,alpha*S+beta);
    logp=logp-sum((F-netSim.f(rr/netSim.K)).^2./(gamma*S+zeta)+log(gamma*S+zeta))/2;
end

return