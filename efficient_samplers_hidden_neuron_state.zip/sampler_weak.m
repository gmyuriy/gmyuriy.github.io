%SAMPLE SEQUENCE OF STATES OF A HIDDEN NEURON FROM A POPULATION OF 
%COUPLED GLM NEURONS GIVEN STATES OF ALL OTHER NEURONS 
%
%METROPOLIS-HASTINGS METHOD IN WEAK APPROXIMATION
%
% Y. Mishchenko 2009 Columbia Un
samples = 100;                    %samples to produce
burn = 100;                       %samples to burn
flg=2;                            %proposal type:
                                  %0 - uniform, 1 - delayed naive, 
                                  %2 - full delayed + advanced

%% EXTRACT PARAMETERS
K=P.K;                            %hidden neuron
T=netSim.T;                       %data length
Np=netSim.N;                      %total neurons

sD=length(netSim.cells(1).h);     %state depth
rD=length(netSim.cells(1).hrefr);
D=max(rD,sD);                     

lidx=((1:Np)==K);                 %hidden neuron selector
No=sum(~lidx);                    %total observed neurons
                                  
logrold=-Inf;                     %previous proposal's R=P/Q
trials=samples + burn;            %total trials

sample=false(trials,T);           %sample container


%% MH-LOOP
tic
rcnt=0;                           %accepted move time-points
f0=[netSim.cells.b0]';            %baseline firing rates
for cnt=1:trials
  %% Generate proposal
  n=false(1,T);                                 %spikes
  H=false(1,rD);                                %container spike-history
  nbuf=0;                                       %buffer spike-history
  logq=0;                                       %log(Q)
  for t=1:T                                     %for all times
    %refractory current on self
    Jj=sum(H.*[netSim.cells(K).hrefr]',2);      
    g=-Jj.*[netSim.cells(K).omega]';            
   
    %incorporate offset currents
    switch flg                                  
      case 0
        g=g+f0(K,t);
      case 1
        g=g+P.J(t);
      case 2
        g=g+P.J(t)+P.Jf(t);
    end
    
    %Bernouli spike prob
    qbuf=-exp(g)*P.dt;                          
    expqbuf=exp(qbuf);    
    nbuf=rand(1,1)>expqbuf;
    n(t)=nbuf;
    
    %shift spike-history container
    H=[H(:,2:end),nbuf];                        
                                                
    %update log(Q)
    if (nbuf) logq=logq+log(1-expqbuf); else logq=logq+qbuf; end    
  end
  
  %% Accept/reject proposal
  logp=0;                                       %log(P)
  Z=P.n;                                        %TOTAL proposed raster
  Z(K,:)=n;                              
  n=Z;
  H=false(Np,D);                                %container spike-history
  nbuf=false(Np,1);                             %buffer spike-history
  for t=1:T                                     %for all times    
    %injected currents:
    Ji=sum(H(:,end-sD+1:end).*[netSim.cells.h]',2); 
    %refractory currents
    Jj=sum(H(:,end-rD+1:end).*[netSim.cells.hrefr]',2); 
    
    f=f0(:,t);                                  %spontaneous
    g=-Jj.*[netSim.cells.omega]';               %refractory contribution    
    g=g+netSim.weights*Ji;                      %cross-current contribution
    
    nbuf=n(:,t);                                %new spikes that HAPPENED    
    H=[H(:,2:end),nbuf];                        %shift spike-history cont.
        
    pbuf=-exp(f+g)*P.dt;                        %update log(P)
    logp=logp+sum(log(1-exp(pbuf(nbuf))))+sum(pbuf(~nbuf));
  end  
  
  logr=logp-logq;                               %log-ratio  P/Q
  
  r=logr-logrold;                               %MH-factor, log
  
  if(cnt==1 || rand<exp(r))                     %accept new move w/ R
    logrold=logr;
    sample(cnt,:)=n(K,:);
    if(cnt>burn) rcnt=rcnt+1; end
  else
    sample(cnt,:)=sample(cnt-1,:);
  end
  
  if(mod(cnt,round(trials/25))==0) fprintf('.'); pause(0.01); end
end
sample=sample(burn+1:end,:);                    %burn samples
fprintf('R=%g\n',rcnt/samples);                 %print acceptance ratio
toc