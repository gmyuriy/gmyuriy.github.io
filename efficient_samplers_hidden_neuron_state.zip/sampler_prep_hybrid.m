%PREPARE INITIAL DATA FOR HYBRID METROPOLIS-HASTINGS-HMM SAMPLER
%
% Y. Mishchenko 2009 Columbia Un
% K=1;                              %hidden neuron idx
% D1=5;                             %grouped state depth included in truncated HMM


%% EXTRACT PARAMETERS
P=[];                             %parameters structure
T=netSim.T;                       %data length
Np=netSim.N;                      %total neurons

sD=length(netSim.cells(1).h);     %state depth, K
rD=length(netSim.cells(1).hrefr);
D=max(rD,sD);                     

lidx=((1:Np)==K);                 %hidden neuron selector
No=sum(~lidx);                    %total observed neurons

P.n=n;                            %full spike raster

P.w=netSim.weights(~lidx,K);      %outgoing connections from hidden
%truncated HMM parameters
P.h=netSim.cells(K).h(end-D1+1:end);
P.hr=netSim.cells(K).omega*netSim.cells(K).hrefr(end-D1+1:end);


%% COMPUTE DELAYED CURRENTS
%this computes J_i(t)=b_{0;i}+sum_{j\in\Omega_o} sum_{t'<t} w_ij(t-t')s_j(t)
% and explicit future observations Y(t)=N(t+1)
fprintf('Preparing offsets...\n');
J=zeros(Np,T);                                %all cross-currents offsets
H=false(Np,D);                                %container spike-history
nbuf=false(Np,1);                             %buffer spike-history
f0=[netSim.cells.b0]';                        %base firing rates
Y=cell(1,T);                                  %observations, future spike
for t=1:T+1                                   %for all times, through T+1 !!
  %injected currents from observed
  Ji=sum(H(~lidx,end-sD+1:end).*[netSim.cells(~lidx).h]',2); 
  %refractory currents for observed
  Jj=sum(H(~lidx,end-rD+1:end).*[netSim.cells(~lidx).hrefr]',2); 
  
  if(t<=T) f=f0(:,t); else f=f0(:,end); end   %spontaneous 
  
  g=f + netSim.weights(:,~lidx)*Ji;           %cross-currents from observed
  
  g(~lidx)=g(~lidx)-Jj.*[netSim.cells(~lidx).omega]';%refractory only for observed !
  
  if t<=T nbuf=n(:,t); else nbuf=false(Np,1); end %update spikes
  H=[H(:,2:end),nbuf];                        %shift spike-history container    

  J(:,t)=g;                                   %record J_i(t)   
  
  if t>1 Y{t-1}=nbuf(~lidx); end              %update future obs Y(t)
    
  if(mod(t,round(netSim.T/25))==0) fprintf('.'); pause(0.01); end
end
fprintf('\n');



%% COMPUTE RESIDUAL ADVANCED CURRENTS
%this compute J^i(t)=sum_{j\in\Omega_o}\sum_{t'>t}w_{ji}(t'-t)(s_j(t)-\Delta f_j(t))
Jf=zeros(1,T);
tempW = [netSim.cells(~lidx).h]';             %only include outer T-D terms
tempW(:,end-D1+1:end)=0;                         
f=exp(J(:,D+1:-1:2));                         %container exp frequency, f(t)
H=n(:,D+1:-1:2);                              %container spike-history, 
for t=1:T                                     %for all times
  %injected currents from observed
  Ji=sum((H(~lidx,:)-netSim.dt*f(~lidx,:)).*tempW,2); 

  %advanced current from observed, w_{>J<i} !!!
  Jf(t)=netSim.weights(~lidx,K)'*Ji;          
  
  tbuf=t+D+1;                                 %spike to be added on the far
                                              %end of H is at t+D+1
  if tbuf<=T nbuf=n(:,tbuf); else nbuf=false(Np,1); end %update stuff
  if (tbuf<=T) fbuf=exp(J(:,tbuf)); else fbuf=exp(f0(:,end)); end
  
                                              %new spikes enter on the far end
  H=[nbuf,H(:,1:end-1)];                      %shift spike-history container    
  f=[fbuf,f(:,1:end-1)];                      %shift exp-freq container    
  
  if(mod(t,round(netSim.T/25))==0) fprintf('.'); pause(0.01); end
end
fprintf('\n');

%% FILL IN PARAMS STRUCTURE
P.K=K;                            %hidden neuron id
P.dt=netSim.dt;                   %time step
P.J=J(K,1:T);                     %J_K(t) for hidden neuron
P.Jo=J(~lidx,2:T+1);              %J_i(t) for observed neurons
P.Jf=Jf;                          %J^i(t), only for hidden neuron

%empty hmm, that's all
if(D1==0) return; end

%% COMPUTE FORWARD PASS P(X(t)|Y(1:t)) (filter)
Ns=2^D1;                          %state space size, note added t'==t spike

p=zeros(Ns,T);                    %P[X(t)|Y(1:t)]
pf=zeros(Ns,T);                   %P[X(t+1)|Y(1:t)]

X=cell(1,T); for t=1:T X{t}=(1:Ns)'; end      %states grid

%INITIALE STATES P(x(1)|Y(1))=P(Y(1)|x(1))P(x(1))/Z
p(:,1)=hmm_PY(P,Y{1},X{1},1).*hmm_PXX(P,X{1}); 
p(:,1)=p(:,1)/sum(p(:,1));                    %normalize

%FORWARD PASS
fprintf('Filter...\n');
for t=2:T
  %this does:
  % P(x(t)|Y(1:t))=P(y(t)|x(t))*int_dx(t-1)P(x(t)|x(t-1))P(x(t-1)|Y(1:t-1))/Z
  nh=size(X{t},1); 
  nhprev=size(X{t-1},1);
  p(1:nh,t)=hmm_PY(P,Y{t},X{t},t);            %P(y(t)|x(t))
  
  %this does:
  % p(x(t)|Y(1:t-1))=int_dx(t-1)P(x(t)|x(t-1))P(x(t-1)|Y(1:t-1))
  pf(1:nh,t)=sum(hmm_PXX(P,X{t},X{t-1},t-1).*repmat(p(1:nhprev,t-1)',nh,1),2);  
  
  %this does: 
  % P(y(t)|x(t))p(x(t)|Y(1:t-1))
  p(1:nh,t)=p(1:nh,t).*pf(1:nh,t); 
  if(sum(p(1:nh,t))==0) 
    error('Fatal: Degenerate prob field (impossible observations!)'); 
  end
  p(1:nh,t)=p(1:nh,t)/sum(p(1:nh,t));
end

%update params structure
P.D1=D1;
P.p=p;
P.pf=pf;
P.Y=Y;
P.X=X;


%% FYI COMPUTE MARGINALS
%BACKWARD PASS
fprintf('Smoother...\n');
pmarg=p;
for t=T-1:-1:1
  %this does:
  % P(x(t)|Y(1:T))=P(x(t)|Y(1:t))*int_dx(t+1)P(x(t+1)|x(t))P(x(t+1)|Y(1:T))/P(x(t+1)|Y(1:t))
  nh=size(X{t},1); 
  nhnext=size(X{t+1},1);  
  a=pf(1:nhnext,t+1); 
  a1=pmarg(1:nhnext,t+1); 
  
  %this does: 
  % P(x(t+1)|Y(1:T))/P(x(t+1)|Y(1:t))
  a(a>0)=a1(a>0)./a(a>0);                     %careful div avoid zeros
  
  %this does: 
  % int_dx(t+1)P(x(t+1)|x(t))P(x(t+1)|Y(1:T))/P(x(t+1)|Y(1:t))
  h=sum(hmm_PXX(P,X{t+1},X{t},t).*repmat(a,1,nh),1)';
  
  %this does: 
  % P(x(t)|Y(1:t))*int_dx(t+1)P(x(t+1)|x(t))P(x(t+1)|Y(1:T))/P(x(t+1)|Y(1:t))
  pmarg(1:nh,t)=pmarg(1:nh,t).*h;
end


%% IMPORTANT NOTE
%spike at t is at states #i like "******1", i.e. state index is even

%===> comment below to turn off display
figure,plot(sum(pmarg(2:2:end,:),1))
title('Spike marginal P(n(t)|*)')
xlabel('Time, ticks'),ylabel('Spike probability')