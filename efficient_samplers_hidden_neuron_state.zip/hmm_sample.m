function [xr,pr]=hmm_sample(P,Y,X,p,pf,n)
%[xr,pr]=popsamp_sample(P,Y,X,p,pf,n)
%Produce a sample of state sequence for hidden neuron given model (P,X), 
%and precomputed forward pass data (p,pf); n is # of samples to draw.
%
% Y. Mishchenko 2009 Columbia Un
if(nargin<5 || isempty(n)) n=1; end

T=size(p,2);
xr=zeros(n,T);                        %n samples T ticks each
pr=zeros(n,1);                        %log-p of each sample (in HMM)

%SAMPLE BACKWARDS
ph=cumsum(p(:,T))/sum(p(:,T));          %choose index ~(x(T)|Y(1:T))
for k=1:n                               %for n-points
  i=find(rand<ph,1);                      
  xr(k,T)=i;
end

for t=T-1:-1:1
  nh=size(X{t},1);

  %this does P(x(t)|y(1:t))P(x(t+1)|x(t))/P(x(t+1)|y(1:t))
  M=hmm_PXX(P,X{t+1},X{t},t);
  F=hmm_PY(P,Y{t+1},X{t+1},t+1);
  
  %choose next point for all samples
  for k=1:n                             
    ph=p(1:nh,t).*M(xr(k,t+1),:)'/pf(xr(k,t+1),t+1);
  
    %check for problems
    if sum(ph)==0                       
      fprintf('Error: degenerate prob field (impossible observations!)\n'); 
      return;
    end
  
    %choose new index ~(x(t)|{Y(1:T),x(t+1:T)})
    ph=cumsum(ph)/sum(ph);              
    i=find(rand<ph,1);
    xr(k,t)=i;
    
    %accumulate log-probabilities
    pr(k)=pr(k)+log(F(xr(k,t+1)))+log(M(xr(k,t+1),xr(k,t))); 
  end
end

%fix probabilities for P(x(t==0))
M=hmm_PXX(P,X{1});                        
F=hmm_PY(P,Y{1},X{1},1);  
for k=1:n pr(k)=pr(k)+log(M(xr(k,1)))+log(F(xr(k,1))); end