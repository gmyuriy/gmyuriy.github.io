%SAMPLE SEQUENCE OF STATES OF A HIDDEN NEURON FROM A POPULATION OF 
%COUPLED GLM NEURONS GIVEN STATES OF ALL OTHER NEURONS AND FLUORESCENCE
%OBSERVATIONS
% Y. Mishchenko 2009 Columbia Un
samples = 100;                    %samples to produce
burn = 100;                       %samples to burn
flg=2;                            %proposal type:
                                  %0 - uniform, 1 - delayed naive, 
                                  %2 - full delayed + advanced
                                  
%% EXTRACT PARAMETERS
K=P.K;                            %hidden neuron
T=netSim.T;                       %data length
Np=netSim.N;                      %total neurons

D1=length(netSim.cells(K).hrefr);   %refraction state depth
sD=length(netSim.cells(1).h);     %state depth
rD=length(netSim.cells(1).hrefr);
D=max(rD,sD);                     

lidx=((1:Np)==K);                 %hidden neuron selector
No=sum(~lidx);                    %total observed neurons
                                  
logrold=-Inf;                     %previous proposal's R=P/Q
trials=samples + burn;            %total trials

sample=false(trials,T);           %sample container
                                  

%% MH-LOOP
alpha   = netSim.cells(K).alpha;    %ALIASES
beta    = netSim.cells(K).beta;
gamma   = netSim.cells(K).gamma;
zeta    = netSim.cells(K).zeta;
step    = netSim.K;
C0      = netSim.cells(K).C_0;    
P1.n    = netSim.cells(K).n;
P1.k_d  = netSim.cells(K).k_d;

fA=netSim.cells(K).A;               %per-spike jump
fg=netSim.dt./netSim.cells(K).tau;  %decay factor

netSim.f=F(K,1:ceil(T/netSim.K));

tic
rcnt=0;                           %accepted move time-points
for cnt=1:trials
  %% Generate proposal                            :: CHECKED OUT
  fC=zeros(1,T);                                %ca
  r=zeros(1,T);
  n=false(1,T);                                 %spikes
  H=false(1,D1);                                %container spike-history
  
  Cbuf=C0;                                      %initial [ca]  
  nbuf=0;                                       %buffer spike-history
  n(1)=nbuf;  
  fC(1)=Cbuf;
  
  logq=0;                                       %log(Q)  
  for t=1:T                                     %for all times
    Jj=sum(H.*[netSim.cells(K).hrefr]',2);      %refractory current on self
    
    g=-Jj.*[netSim.cells(K).omega]';            %refractory contribution
   
    switch flg                                  %incorporate offset currents
      case 0
        g=g+netSim.cells(K).b0;
      case 1
        g=g+P.J(t);
      case 2
        g=g+P.J(t)+P.Jf(t);
    end
        
    p=1-exp(-exp(g)*P.dt);                      %Bernouli spike prob
    
    if(t==1) p=0; end                           %t==1 delta function    
    
    %modify prob to P(F_{t:T}|q_t,C_t)P(q_t,C_t|q_{t-1},C_{t-1})
    qon=bin2dec(sprintf('%i',[H(2:end),1]))+1;
    qoff=bin2dec(sprintf('%i',[H(2:end),0]))+1;
    
    Con=(1-fg)*Cbuf+fg*C0+fA;                     %C_t|q_t=1
    Coff=(1-fg)*Cbuf+fg*C0;                       %C_t|q_t=0    
    
    mon=R(t).m(qon,:);
    moff=R(t).m(qoff,:);
    
    s2on=R(t).s2(qon,:);
    s2off=R(t).s2(qoff,:);
    
    pon=sum(R(t).p(qon,:).*exp(-(Con-mon).^2./(2*s2on))./sqrt(s2on));
    poff=sum(R(t).p(qoff,:).*exp(-(Coff-moff).^2./(2*s2off))./sqrt(s2off));    
    p=p*pon/(p*pon+(1-p)*poff);
    
  
    nbuf=rand<p;                   
    if nbuf 
        n(t)=1; 
        Cbuf=Con;
    else
        n(t)=0;
        Cbuf=Coff;
    end
    
    r(t)=p;                                         %record    
    fC(t)=Cbuf;
    
    H=[H(:,2:end),nbuf];                        %shift spike-history container
                                                %update log(Q)
    if nbuf logq=logq+log(p); else logq=logq+log(1-p); end    
  end
  rq=r;
  
  
  %% Accept/reject proposal                       :: CHECKED OUT
  Z=P.n(:,1:T);                                 %TOTAL proposed raster
  Z(K,:)=n;                                   
  logp=glmlogp(Z,netSim);                       %with proposal for neuron K    
  
  logr=logp-logq;                               %log-ratio  P/Q
  
  r=logr-logrold;                               %MH-factor, log
  if(rand<exp(r))                               %accept new move w/ R
    logrold=logr;
    sample(cnt,:)=n(K,:);
    if(cnt>burn) rcnt=rcnt+1; end    
  else
    sample(cnt,:)=sample(cnt-1,:);
  end
  
  if(mod(cnt,round(trials/25))==0) fprintf('.'); pause(0.01); end
end
sample=sample(burn+1:end,:);                    %burn samples
fprintf('R=%g\n',rcnt/samples);                 %print acceptance ratio
toc