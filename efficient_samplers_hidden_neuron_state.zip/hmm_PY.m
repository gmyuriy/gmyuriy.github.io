function Z=spPY(P,Y,X,t)
%HMM observation function P(Y|X,t)
%Z=PY(p,Y,X,t) computes P(Y|X,t). If X is a NxM matrix of N M-dimensional
%states, Z is a Nx1 vector of the probabilities (Y should be a scalar or
%nan to indicate missing observations. "p" is a structure of parameters.
%
% Y. Mishchenko 2009 Columbia Un

%% Set some parameters
Jf=P.Jf(t);                 %advanced correction for hidden neuron
J=P.Jo(:,t);                %delayed currents for observed neurons
h=P.h;                      %hidden neuron cross-coupling waveform
W=P.w;                      %hidden neuron cross-coupling weights
D=length(h);                %grouped state depth
Ns=2^D;                     %states ##
dt=P.dt;                    %size of ticks

%% P(Y|X) for last t, special i.e. no future info at t=max_t
M=zeros(Ns,1);
if(t==size(P.Jo,2)) Z=ones(size(X)); return; end  


%% Calculate 2^D x 1 P(Y|X) due to truncated HMM
for K=1:Ns                  
    %note this does P(N(t+1)|n(t)) - thus alignment of state-string & P.h (!!!)
    state=dec2bin(K-1,D);   %state string for K
    
    pos=strfind(state,'1'); %elements of n=1 in the state
    
    j=exp(J+W*sum(h(pos))); %instanteneous rate for observed neurons
    
    M(K)=sum(log(1-exp(-dt*j(Y>0))))-dt*sum(j(Y==0));    
end

%% Calculate effective correction due to weak approx
s=mod(X+1,2);
M=M + s*Jf;

Z=exp(M-max(M));
