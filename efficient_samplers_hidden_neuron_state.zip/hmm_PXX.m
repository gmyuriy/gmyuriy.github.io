function Z=hmm_PXX(P,X1,X0,t)
%HMM transition function P(X1|X0,t)
%Z=PXX(p,X1) computes the probability P(X1,t==0). If X1 is NxM matrix of N
%M-dimensional states, Z is a Nx1 vector of such probabilities.
%Z=PXX(p,X1,X0,t) computes P(X1|X0,t). If X1 is NxM matrix and X0 is KxM
%matrix of N and K M-dimensional states, respecitvely, Z is a NxK matrix
%of transition probabilities between these states P(i,j)=P(X1(i)|X0(j),t).
%"p" is a structure of parameters. 
%
% Y. Mishchenko 2009 Columbia Un
if(nargin<4) t=1; end

%% Set some parameters
h=P.hr;                     %self-interaction waveform, pay attention to order /below/
J=P.J(t+1);                 %injected delayed current, for t+1 /bc for spike at t+1/
D=length(h);                %state depth
Ns=2^D;                     %states count
dt=P.dt;                    %tick size

%% Calculate 2^D x 1 P(X), initial distribution 
if(nargin<3)  
  M=zeros(Ns,1);
  
  K1=2;                     %start off with only two states, s='00001'
  K2=1;                     %all zeros, s='00000'
  
  j=exp(P.J(1));                 
  p=exp(-dt*j);             %prob spike at first time-bin
  M(K1)=1-p;
  M(K2)=p;
  Z=M(X1);
else  
%% Calculate 2^D x 2^D P(X|X), transition matrix 
  %note this does P(n(t+1)|n(t)) - thus alignment of state strings & P.h (!!!)
  M=zeros(Ns,Ns);           %M - transition matrix         
  for K=1:Ns
    state=dec2bin(K-1,D);   %state string for state K
    pos=strfind(state,'1'); %elements of n=1 in this state
                                      
    j=exp(J - sum(h(pos))); %instanteneous rate + refractory
    
    L=bin2dec([state(2:end),'0'])+1;  %transition to no spike at t+1
    p=exp(-dt*j);
    M(L,K)=p;
    
    L=bin2dec([state(2:end),'1'])+1;  %transition to spike at t+1
    M(L,K)=1-p;
  end  
  Z=M(X1,X0);
end
