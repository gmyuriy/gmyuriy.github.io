%SCRIPT TO GENERATE SPIKE RASTERS FOR POPULATION OF COUPLED GLM NEURONS
%
%STRONGLY COUPLED POPULATION
%
% Y. Mishchenko 2009 Columbia Un
rndinit = 3467;                     %random init seed, for repeatability
rand('state',rndinit);              
randn('state',rndinit);
netSim.rnd=rndinit;


%% BASIC PARAMETERS
mon=1;                              %neuron ind to monitor, test

T = 1;                              %recording time, sec
N = 50;                             %# of neurons
SC = 10;                            %coupling scale multiple
SP = 0.1;                           %coupling matrix sparseness
Delta=0.002;                        %simulation time step, Delta

rD=5;                               %depth of refraction state
sD=25;                              %depth of interaction state

FR=50;                              %fluorescence observations frame rate
G=1E4;                              %signal strength, photons-per-frame
lin=0;                              %linear fluor. transfer function?


%% DETAILED PARAMETERS
netSim.FR=1/FR;                     %sampling time step
netSim.dt=Delta;                    %simulation time-step, sec
netSim.T=ceil(T/netSim.dt);         %simulation duration, ticks

netSim.N=N;                         %number of cells
netSim.SP=SP;                       %sparseness of connections
netSim.balance=0.2;                 %fraction of inhibitory neurons
netSim.scaleE=SC*0.025;             %excitotary scale
netSim.scaleI=SC*0.1;               %inhibitory scale

%ALL PARAMETERS ARE GIVEN AS TRIPLE [MIN,MEAN,STD]
netSim.rate =[0 5 0];               %spontaneous ignition rate,exc neurons
netSim.irate=[0 5 0];               %spontaneous ignition rate,inh neurons
netSim.omega=[0 10 0];              %refractory term amplitude 

netSim.tauexc=0.01/netSim.dt*[0 1 0];   %excitatory decay constant, ticks
netSim.tauinh=0.02/netSim.dt*[0 1 0];   %inhibitory decay constant, ticks
netSim.tauref=0.01/netSim.dt*[0 1 0];   %refractory decay constant, ticks

netSim.C_0=[0.05 0.30 0.1];         %Ca-baseline
netSim.A=[20 40 12];                %Ca-jump
netSim.sigma=[0.0 0.0 0.0];         %Ca-noise
netSim.tau=[0.15 0.25 0.05];        %Ca-decay constant

netSim.n=1;                         %Hill-transfer-function, exponent
netSim.k_d=100;                     %Hill-transfer-function, dissoc. coeff.

netSim.alpha=[0 1 0];               %fluorescence scaling
netSim.beta =[0 0 0];               %fluorescence offset
netSim.G=G*[0.3 1 0.5];             %fluorescence shot noise
netSim.Z=[0 5 0];                   %fluorescence background noise [rel gamma]

netSim.transf_lin = lin;            %is transfer linear func
if(lin==0)
  netSim.hill=inline('C.^(P.n)./(C.^(P.n)+P.k_d)','P','C'); %trnsf nonlinearity
  netSim.ihill=inline('(S./(1-S)*P.k_d).^(1/P.n)','P','S'); %inverse
  netSim.dihill=inline('C./(P.n.*S.*(1-S))','P','C','S');   %inv diff
else
  netSim.hill=inline('C/P.k_d','P','C');                    %same, lin trnsf
  netSim.ihill=inline('P.k_d*S','P','S');
  netSim.dihill=inline('P.k_d','P','C','S');
end


%%%%%%%%% ADJUSTMENTS
netSim.K=round(netSim.FR/netSim.dt);%sampling/sim time-steps ratio
if(N>100) netSim.scaleI=0.2; end  %stronger inhibition necessary larger N
if(N>400) netSim.scaleI=0.25; end



%% CONNECTIVITY MATRIX
%sparse::exp-distr::order POST-PRE|(i,j)
netSim.weights=sparse(double(rand(netSim.N)<=netSim.SP));

dT=0.01;                          %EPSP typical time-scale
rate=netSim.rate(2);              %mean firing rate
signs=zeros(netSim.N,1);          %neuron sign, I/E
Ninh=round(netSim.N*netSim.balance);%number of inhibitory neurons
netSim.signs=signs;               %record of neurons' signs

%excitatory neurons -- log-rates from exp-distr biophysical strengths
Zmin=1e-6;                              %truncation, for log below
idx=1:netSim.N-Ninh; 
signs(idx)=1;                           %exc neurons
W=netSim.weights(:,idx); 
ind=find(W>0);                          %which pairs have connections
z=netSim.scaleE*exprnd(1,length(ind),1);  %exp distr biophys strengths, V_ij
z=log(-log(max(Zmin,exp(-rate*dT)-z))/(rate*dT)); %log-transformed to w_ji
W(ind)=z; 
netSim.weights(:,idx)=W;                %copy into weights

%inhibitory neurons -- log-rates from exp biophysical strengths
Zmin=1e-6;                              %truncation for log below
idx=netSim.N-Ninh+1:netSim.N; 
signs(idx)=-1;                          %inh neurons
W=netSim.weights(:,idx); 
ind=find(W>0);                          %which pairs have connections
z=netSim.scaleI*exprnd(1,length(ind),1);  %exp distr biophys strengths, V_ij
z=-log(-log(max(Zmin,exp(-rate*dT)-z))/(rate*dT));  %log-transformed to w_ij
W(ind)=z; 
netSim.weights(:,idx)=W;                %copy into weights

%remove self-coupling /refractory terms responsible for that/
for k=1:netSim.N netSim.weights(k,k)=0; end

%print some statistics
fprintf('W-scale: %g;%g\n',...
  mean(abs(full(netSim.weights(netSim.weights>0)))),...
   mean(abs(full(netSim.weights(netSim.weights<0)))));
 


%% INDIVIDUAL NEURON MODELS
randtrn=inline('max(A(1),A(2)+randn*A(3))','A');  %truncated Gaussian distr
netSim.cells=[];
for k=1:netSim.N
  c=[];
        
  c.A=randtrn(netSim.A);                %calcium jump
  c.C_0=randtrn(netSim.C_0)*c.A;        %calcium base
  c.sigma=randtrn(netSim.sigma)*c.A;    %calcium noise
  c.tau=randtrn(netSim.tau);            %calcium decay

  c.n=netSim.n;                         %Hill-funct, exp
  c.k_d=netSim.k_d;                     %Hill-funct, K_d

  c.alpha=randtrn(netSim.alpha);        %fluorescence alpha
  c.beta=randtrn(netSim.beta);          %fluorescence beta
  c.gamma=1/randtrn(netSim.G);          %fluorescence gamma
  c.zeta=randtrn(netSim.Z)*c.gamma;     %fluorescence zeta  
  
  c.omega=randtrn(netSim.omega);        %refractory Omega
    
                                        %base firing rate
  if(signs(k)>0)                        %admit two rates for I/E
    c.rate=randtrn(netSim.rate);        
  else
    c.rate=randtrn(netSim.irate);
  end
  
  c.b0=zeros(netSim.T,1);               %baseline firing rates
  c.b0(:)=log(c.rate);  

  tauexc=randtrn(netSim.tauexc);
  tauinh=randtrn(netSim.tauinh);
  tauref=randtrn(netSim.tauref);  
  
  %coupling waveforms /inh & exc should be the same ticks-length/
  t=(sD:-1:0);                           %profile depth
  if(signs(k)>0)
    h=exp(-t/tauexc);
    c.htau=tauexc;
    c.h=h(1:end-1)'/max(h);             %EPSP profile
  else  
    h=exp(-t/tauinh);
    c.htau=tauinh;
    c.h=h(1:end-1)'/max(h);             %IPSP profile
  end
  
  t=(rD:-1:0);
  h=exp(-t/tauref);
  c.rtau=tauref;
  c.hrefr=h(1:end-1)'/max(h);           %REFR profile  
  
  if(isempty(netSim.cells)) netSim.cells=c; else netSim.cells(k)=c; end
end


%% COMPUTE SPIKE RASTER
fprintf('Generating firing patterns...\n');
Np=netSim.N;
n=false(Np,T);                                %spikes
H=false(Np,max(sD,rD));                       %container spike-history
nbuf=false(Np,1);                             %buffer spike-history
Jm=zeros(1,T);                                %control variable
f0=[netSim.cells.b0]';                        %base firing rates
for t=1:netSim.T                              %for all times
  Ji=zeros(Np,1);                             %injected currents:
  Ji=sum(H(:,end-sD+1:end).*[netSim.cells.h]',2); 
  Jj=sum(H(:,end-rD+1:end).*[netSim.cells.hrefr]',2); %refractory currents
  
  %SPIKE
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  f=f0(:,t);                                  %spontaneous
  g=-Jj.*[netSim.cells.omega]';               %refractory  
  g=g+netSim.weights*Ji;                      %cross-currents
  
  Jm(t)=f(mon)+netSim.weights(mon,:)*Ji;      %record control, for tests
  
  logpbuf=-exp(f+g)*netSim.dt;
  if(t==1) logpbuf(:)=0; end                  %first no-spike delta-func
  
  nbuf=rand(Np,1)>exp(logpbuf);               %Bernouli spike  

  n(nbuf,t)=1;
    
  H=[H(:,2:end),nbuf];                        %shift spike-history container

  if(mod(t,round(netSim.T/25))==0) fprintf('.'); pause(0.01); end
end
fprintf('\n');

%print some statistics
rate=mean([netSim.cells.rate]);
ntote=sum(sum(n(signs>0,:)));
ntoti=sum(sum(n(signs<0,:)));
fprintf('Base rate %.3g; actual rates %.3g/%.3g Hz\n',mean(rate),...
  ntote/sum(signs>0)/(netSim.T*netSim.dt),...
  ntoti/sum(signs<0)/(netSim.T*netSim.dt));


%% COMPUTE CALCIUM VARIABLE
fprintf('Generating calcium variable...\n');
A     = [netSim.cells.A]';                    %aliases
sigma = [netSim.cells.sigma]';
tau   = [netSim.cells.tau]';
C_0   = [netSim.cells.C_0]';
a     = netSim.dt./tau;

Cbuf=C_0;
C=zeros(Np,ceil(netSim.T/netSim.K));
for t=1:netSim.T
  Cbuf=(1-a).*Cbuf + a.*C_0 + A.*n(:,t) + sigma.*sqrt(netSim.dt).*randn(Np,1);
  
  Cbuf=max(0,Cbuf);                           %can't get smaller than 0
  
  if(mod(t,netSim.K)==0) C(:,t/netSim.K)=Cbuf; end  %record calcium sample
end


%% COMPUTE FLUORESCENCE VARIABLE
fprintf('Generating fluorescence variable...\n');
F=zeros(size(C));
for k=1:netSim.N
  alpha   = netSim.cells(k).alpha;            %aliases
  beta    = netSim.cells(k).beta;
  gamma   = netSim.cells(k).gamma;
  zeta    = netSim.cells(k).zeta;
  P.n     = netSim.n;
  P.k_d   = netSim.k_d;

  S=netSim.hill(P,C(k,:));
  F(k,:)=max(0,alpha*S+beta+sqrt(gamma*S+zeta).*randn(size(S)));
end


%% COMPUTE & PRINT SNR
SNR=0;
for k=1:size(n,1)
  H=false(size(F(k,:)));
  H(min(length(H),ceil(find(n(k,:))/netSim.K)))=1;
  if(sum(H)==0) continue; end
  dF=[0,im2double(F(k,2:end))-im2double(F(k,1:end-1))];
  
  SNR=SNR+mean(abs(dF(H)))/mean(abs(dF(~H)));
end
SNR=SNR/size(n,1);
fprintf('SNR: %g\n',SNR);


%% clean up the mess
clear Delta N SC dF dT f0 ind lin logpbuf rD sD tauexc tauinh tauref
clear A C_0 Cbuf FR G H Ji Jj Jm Ninh Np P S SP T W Zmin a alpha beta
clear c f g gamma h idx k nbuf ntote ntoti randtrn rate rndinit
clear sigma signs t tau z zeta